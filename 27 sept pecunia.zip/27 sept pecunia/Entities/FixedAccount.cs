﻿using Pecunia.Helpers.ValidationAttribute;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Entities
{
    /// <summary>
    /// Interface of Fixed Entity
    /// </summary>
    public interface IFixedAccount
    {
        double Tenure { get; set; }
        double FDDeposit { get; set; }
    }

    /// <summary>
    /// Represents Fixed Deposit Account
    /// </summary>
    public class FixedAccount : IRegularAccount, IFixedAccount
    {

        /*Auto-Imlemented Properties*/
        [Required("Account ID can't be blank.")]
        public Guid AccountID { get; set; }

        [Required("Customer ID can't be blank.")]
        public Guid CustomerID { get; set; }

        [Required("Customer No can't be blank.")]
        [RegExp(@"^[0-9]{6}$", "Customer number should contain 6 digits")]
        public string CustomerNo { get; set; }

        //[RegExp(@"^[1]\d{9}$", "Account number should start with 1 and should contain 10 digits")]
        public string AccountNo { get; set; }

        [Required("Current Balance can't be negative.")]
        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Current Balance is invalid.")]
        public double CurrentBalance { get; set; }

        [Required("Account Type can't be blank")]
        public string AccountType { get; set; }

        [Required("Branch can't be blank.")]
        public string Branch { get; set; }

        public string Status { get; set; }

        [Required("Minimum Balance can't be negative.")]
        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Minimum Balance is invalid.")]
        public double MinimumBalance { get; set; }

        [Required("Interest Rate can't be negative.")]
        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Interest Rate is invalid.")]
        public double InterestRate { get; set; }

        [Required("Tenure can't be negative.")]
        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "Tenure is invalid.")]
        public double Tenure { get; set; }

        [Required("FDDeposit Amount can't be negative.")]
        [RegExp(@"^[+]?([0-9]+(?:[\.][0-9]*)?|\.[0-9]+)$", "FDDeposit Amount is invalid.")]
        public double FDDeposit { get; set; }

        public DateTime CreationDateTime { get; set; }
        public DateTime LastModifiedDateTime { get; set; }

        /*Constructor*/
        public FixedAccount()
        {
            AccountID = default(Guid);
            CustomerID = default(Guid);
            CustomerNo = null;
            AccountNo = null;
            CurrentBalance = 0;
            AccountType = null;
            Branch = null;
            MinimumBalance = 0;
            InterestRate = 0;
            Status = "Active";
            Tenure = 0;
            FDDeposit = 0;
            CreationDateTime = default(DateTime);
            LastModifiedDateTime = default(DateTime);

        }
    }
}
﻿using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Contracts.DALContracts;
using Pecunia.DataAcessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Exceptions;
using Pecunia.Helpers;

namespace Pecunia.BusinessLayer
{
    /// <summary>
    /// Contains data access layer methods for creating, updating, deleting accounts from Accounts collection.
    /// </summary>
    public class FixedBL : BLBase<Fixed>, IFixedBL, IDisposable
    {
        //fields
        FixedDALBase fixedDAL;

        /// <summary>
        /// Constructor.
        /// </summary>
        public FixedBL()
        {
            this.fixedDAL = new FixedDAL();
        }

        /// <summary>
        /// Validations on data before adding or updating.
        /// </summary>
        /// <param name="entityObject">Represents object to be validated.</param>
        /// <returns>Returns a boolean value, that indicates whether the data is valid or not.</returns>

        protected async override Task<bool> Validate(Fixed entityObject)
        {

            //Create string builder
            StringBuilder sb = new StringBuilder();
            bool valid = await base.Validate(entityObject);

            //Branch should be in (Mumbai,Bangalore,Delhi,Chennai)
            List<Fixed> tf = await (GetAccountsByBranchBL(entityObject.Branch));
            var existingObject = tf[0];
            if (existingObject != null && existingObject?.AccountID != entityObject.AccountID)
            {
                valid = false;
                sb.Append(Environment.NewLine + $"Branch {entityObject.Branch} doesn't exists");
            }

            if (valid == false)
                throw new PecuniaException(sb.ToString());
            return valid;

        }


        /// <summary>
        /// Adds new account to Accounts collection.
        /// </summary>
        /// <param name="newFixed">Contains the account details to be added.</param>
        /// <returns>Determinates whether the new supplier is added.</returns>
        public async Task<bool> CreateAccountBL(Fixed newFixed)
        {
            bool AccountCreated = false;
            try
            {
                if (await Validate(newFixed))
                {
                    await Task.Run(() =>
                    {
                        this.fixedDAL.CreateAccountDAL(newFixed);
                        if (fixedDAL.GetAllAccountsDAL().Count == 0)
                        {
                            newFixed.AccountNo = Convert.ToString(AccountsConfiguration.baseAccountNo2);
                        }
                        else
                        {
                            string nextAccountNo = (fixedDAL.GetAllAccountsDAL().Max(temp => long.Parse(temp.AccountNo)) + 1).ToString();
                            newFixed.AccountNo = nextAccountNo;
                        }
                        newFixed.InterestRate = AccountsConfiguration.interest;
                        newFixed.MinimumBalance = AccountsConfiguration.minbal;
                        newFixed.CurrentBalance = 0;
                        AccountCreated = true;
                        Serialize();
                    });
                }
            }
            catch (Exception)
            {
                throw;
            }

            return AccountCreated;
        }

        /// <summary>
        /// Gets all accounts from the collection.
        /// </summary>
        /// <returns>Returns list of all accounts.</returns>
        public async Task<List<Fixed>> GetAllAccountsBL()
        {
            List<Fixed> fixedList = null;
            try
            {
                await Task.Run(() =>
                {
                    fixedList = fixedDAL.GetAllAccountsDAL();
                });

            }
            catch (Exception)
            {
                throw;
            }
            return fixedList;
        }

        /// <summary>
        /// Gets account based on AccountNo
        /// </summary>
        /// <param name="searchAccountNo">Contains the account no to search the account.</param>
        /// <returns>returns the object of Account Class.</returns>
        public async Task<Fixed> SearchAccountByAccountNoBL(string searchAccountNo)
        {
            Fixed searchAccount = null;
            try
            {
                await Task.Run(() =>
                {
                    searchAccount = fixedDAL.SearchAccountByAccountNoDAL(searchAccountNo);
                });

            }
            catch (Exception)
            {
                throw;
            }
            return searchAccount;

        }



        /// <summary>
        /// Gets list of accounts based on CustomerNo
        /// </summary>
        /// <param name="searchCustomerNo">Contains the Customer No to search the accounts.</param>
        /// <returns>Returns the list of Account class objects where the Customer No matches.</returns>
        public async Task<List<Fixed>> GetAccountsByCustomerNoBL(string searchCustomerNo)
        {

            List<Fixed> AccountsByCustNo = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByCustNo = fixedDAL.GetAccountsByCustomerNoDAL(searchCustomerNo);
                });


            }
            catch (Exception)
            {
                throw;
            }
            return AccountsByCustNo;

        }

        /// <summary>
        /// Gets list of accounts based on branch
        /// </summary>
        /// <param name="searchBranch">Contains the account in a particular branch.</param>
        /// <returns>Returns the list of Account class objects.</returns>
        public async Task<List<Fixed>> GetAccountsByBranchBL(string searchBranch)
        {

            List<Fixed> AccountsByBranch = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByBranch = fixedDAL.GetAccountsByBranchDAL(searchBranch);
                });

            }

            catch (Exception ex)
            {
                throw ex;
            }
            return AccountsByBranch;

        }

        /// <summary>
        /// Gets list of accounts based on range of dates
        /// </summary>
        /// <param name="d1">Contains the starting date.</param>
        /// <param name="d2">Contains the ending date.</param>
        /// <returns>Returns the list of Account class objects.</returns>
        public async Task<List<Fixed>> GetAccountsByAccountOpeningDateBL(DateTime d1, DateTime d2)
        {

            List<Fixed> AccountsByDate = null;
            try
            {
                await Task.Run(() =>
                {
                    AccountsByDate = fixedDAL.GetAccountsByAccountOpeningDateDAL(d1, d2);
                });

            }

            catch (Exception)
            {
                throw;
            }
            return AccountsByDate;

        }

        /// <summary>
        /// Gets Current Balance in the account
        /// </summary>
        /// <param name="accountNumber">Contains the account number for which balance is requested.</param>
        /// <returns>Returns the current balance.</returns>
        public async Task<double> GetBalanceBL(string accountNumber)
        {

            double balance = 0;
            try
            {
                await Task.Run(() =>
                {
                    balance = fixedDAL.GetBalanceDAL(accountNumber);
                });
            }
            catch (Exception)
            {
                throw;
            }
            return balance;

        }

        /// <summary>
        /// Updates the balance after every transaction
        /// </summary>
        /// <param name="accountNumber">Contains the account number.</param>
        /// <param name="balance">Contains the updated balance after a transaction .</param>
        /// <returns>Determines whether the account balance is updated or not.</returns>
        public async Task<bool> UpdateBalanceBL(string accountNumber, double balance)
        {

            bool BalanceUpdated = false;

            try
            {
                if (await SearchAccountByAccountNoBL(accountNumber) != null)
                {
                    fixedDAL.UpdateBalanceDAL(accountNumber, balance);
                    BalanceUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }

            return BalanceUpdated;
        }

        /// <summary>
        /// Updates the branch of an account
        /// </summary>
        /// <param name="accountNumber">Contains the account number of the account.</param>
        /// <returns>Determines whether the branch is updated or not.</returns>
        public async Task<bool> UpdateBranchBL(string accountNumber, string branch)
        {
            bool AccountBranchUpdated = false;
            try
            {
                if (await SearchAccountByAccountNoBL(accountNumber) != null)
                {
                    this.fixedDAL.UpdateBranchDAL(accountNumber, branch);
                    AccountBranchUpdated = true;
                    Serialize();
                }
            }
            catch (Exception)
            {
                throw;
            }

            return AccountBranchUpdated;
        }


        /// <summary>
        /// Deletes an existing account
        /// </summary>
        /// <param name="deleteAccountNo">Contains the account number of the account to be deleted.</param>
        /// <returns>Determines whether the account is deleted or not.</returns>
        public async Task<bool> DeleteAccountBL(string deleteAccountNo)
        {
            bool AccountDeleted = false;
            try
            {
                if (await SearchAccountByAccountNoBL(deleteAccountNo) != null)
                {
                    this.fixedDAL.DeleteAccountDAL(deleteAccountNo);
                    AccountDeleted = true;
                    Serialize();
                }
            }

            catch (Exception)
            {
                throw;
            }

            return AccountDeleted;
        }

        /// <summary>
        /// Disposes DAL object(s).
        /// </summary>
        public void Dispose()
        {
            ((FixedDAL)fixedDAL).Dispose();
        }

        /// <summary>
        /// Invokes Serialize method of DAL.
        /// </summary>
        public static void Serialize()
        {
            try
            {
                AccountDAL.Serialize();
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        ///Invokes Deserialize method of DAL.
        /// </summary>
        public static void Deserialize()
        {
            try
            {
                AccountDAL.Deserialize();
            }
            catch (Exception)
            {
                throw;
            }
        }
    }
}


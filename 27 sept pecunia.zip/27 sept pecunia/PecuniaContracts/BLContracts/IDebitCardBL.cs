﻿using Pecunia.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Contracts.BLContracts
{
    public interface IDebitCardBL : IDisposable
    {

        Task<bool> AddDebitCardBL(DebitCard debitCard);
        Task<List<DebitCard>> GetAllDebitCardsBL();
        Task<bool> UpdateDebitCardStatusBL(string cardNumber, string cardStatus);
        Task<List<DebitCard>> GetDebitCardsByAccountIdBL(Guid accountId);
        Task<DebitCard> GetDebitCardByDebitCardNumberBL(string debitCardNumber);


    }
}

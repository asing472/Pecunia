﻿using Pecunia.Entities;
using Pecunia.Contracts.DALContracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.DataAcessLayer
{/// <summary>
 /// Contains  methods for inserting, updating and searching debitcards from ChequeBooks collection.
 /// </summary>

    public class ChequeBookDAL : ChequeBookDALBase, IDisposable
    { /// <summary>
      /// Adds new chequeBook to ChequeBooks collection.
      /// </summary>
      /// <param name="chequeBook">Contains the chequebook details to be added.</param>
      /// <returns>Determines whether the new   cheque book is requested.</returns>
        public override bool AddChequeBookDAL(ChequeBook chequeBook)
        {
            bool chequeBookIssued = false;
            try
            {
                chequeBook.ChequeBookId = DateTime.Now.ToString("yyyyMMDDHHmm");
                chequeBook.ChequeBookStatus = "Requested";
                chequeBooksList.Add(chequeBook);
                chequeBookIssued = true;
            }
            catch (Exception)
            {
                throw;
            }
            return chequeBookIssued;

        }
        /// <summary>
        /// Returns chequeBook list
        /// </summary>
        /// <returns> Returns the list of chequeBooks</returns>
        public override List<ChequeBook> GetChequeBookListDAL()
        {
            return chequeBooksList;
        }
        /// <summary>
        /// Updates the status of debit card
        /// </summary>
        /// <param name="chequeBookId">Contains the chequeBookId for which we need to change status</param>

        /// <returns>Returns bool value if updated or not</returns>
        public override bool UpdateChequeBookStatusDAL(string chequeBookId)
        {
            bool chequeBookStatusChanged = false;
            try
            {
                ChequeBook chequeBook = null;
                chequeBook = chequeBooksList.Find(x => x.ChequeBookId == chequeBookId);

                if (chequeBook != null)
                {

                    chequeBook.ChequeBookStatus = "Updated";

                    chequeBookStatusChanged = true;
                }
            }
            catch (Exception)
            {
                throw;
            }
            return chequeBookStatusChanged;
        }
        /// <summary>
        /// Gets chequeBook based on chequeBookID.
        /// </summary>
        /// <param name="debitId">Represents ChequeBookID to search.</param>
        /// <returns>returns cheque book details for respective cheque book Id</returns>
        public override ChequeBook GetChequeBookByChequeBookIdDAL(string chequeBookId)
        {
            ChequeBook searchDebit = null;
            try
            {
                searchDebit = chequeBooksList.Find(x => x.ChequeBookId == chequeBookId);
            }
            catch (Exception)
            {
                throw;
            }
            return searchDebit;
        }
        /// <summary>
        /// Gets list of chequeBooks based on AccountID.
        /// </summary>
        /// <param name="accountId">Represents AccountID to search.</param>
        /// <returns>returns list of cheque books details for respective AccountId</returns>
        public override List<ChequeBook> GetChequeBooksByAccountIdDAL(Guid accountId)
        {
            List<ChequeBook> ChequeBooksByAccountID = new List<ChequeBook>();
            try
            {

                ChequeBooksByAccountID.AddRange(chequeBooksList.FindAll(x => x.AccountId == accountId));

            }
            catch (Exception)
            {
                throw;
            }
            return ChequeBooksByAccountID;
        }



        /// <summary>
        /// Clears unmanaged resources such as db connections or file streams.
        /// </summary>
        public void Dispose()
        {
            //No unmanaged resources currently
        }

    }
}

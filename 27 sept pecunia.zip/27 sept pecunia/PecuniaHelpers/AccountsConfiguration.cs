﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pecunia.Helpers
{
    /// <summary>
    /// Assigning starting and default value to accounts
    /// </summary>
    public class AccountsConfiguration
    {
        public static long baseAccountNo1 = 1000000000;
        public static long baseAccountNo2 = 2000000000;
        public static double interest = 3.5;
        public static double minbal = 500;
    }
}

﻿using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Exceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Console;

namespace Pecunia.PresentationLayer
{
    class EmployeePresentation
    {
        public static async Task<int> EmployeeUserMenu()
        {
            int choice = -1;
            do
            {

                WriteLine("\n1. Customer Services");
                WriteLine("2. Account Services");
                WriteLine("3. Transaction Services");
                WriteLine("4. Loan Services");
                WriteLine("5. Utilities Services");


                WriteLine("-----------------------");
                WriteLine("0. Exit");
                Write("Choice: ");
                bool isValidChoice = int.TryParse(ReadLine(), out choice);
                if (isValidChoice)
                {
                    switch (choice)
                    {
                        case 1: await CustomerPresentation.CustomerMenu(); break;
                        case 2: await AccountsPresentation.AccountsMenu(); break;
                        case 3: await TransactionPresentation.TransactionMenu(); break;
                        case 4: await LoanPresentation.LoanMenu(); break;
                        case 5: await UtilitiesPresentation.UtilitiesMenu(); break;


                        case 0: break;

                        default: WriteLine("Invalid Choice"); break;
                    }
                }
                else
                {
                    choice = -1;
                }
            } while (choice != 0 && choice != -1);
            return choice;
        }
    }
}

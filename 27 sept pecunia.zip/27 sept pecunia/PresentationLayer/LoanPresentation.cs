﻿using Pecunia.Entities;
using Pecunia.BusinessLayer;
using Pecunia.Contracts.BLContracts;
using Pecunia.Exceptions;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Pecunia.PresentationLayer
{
    class LoanPresentation
    {
        /// <summary>
        /// To  Operate on Loan Managment system
        /// </summary>
        /// <returns></returns>
        public static async Task<int> LoanMenu()
        {
            int Ch = 1;

            do
            {
                //Menu for Loan managment services
                Console.WriteLine("\n***************Loan Managment System***********");

                Console.WriteLine("1. Car Loan Services");
                Console.WriteLine("2. Home Loan Services");
                Console.WriteLine("3. Education Loan Services");
                Console.WriteLine("4. Personal Loan Services");
                Console.WriteLine("5. Serialize");
                Console.WriteLine("-1. Exit");
                Console.WriteLine("Enter Choice");
              
                //Accept and check choice
                Ch = int.Parse(Console.ReadLine());

                if (Ch == 1)
                {
                    //Menu for CarLoan managment services
                    int choice1 = -2;
                    do
                    {
                        Console.WriteLine("\n***************Car Loan Services***********");

                        Console.WriteLine("1. Apply For Car Loan");
                        Console.WriteLine("2. Update Car Loan");
                        Console.WriteLine("3. Delete Car Loan");
                        Console.WriteLine("4. Show All Car Loan");
                        Console.WriteLine("5. Search Car Loan By Loan Status");
                        Console.WriteLine("-1 For Exit");
                        Console.WriteLine("Enter Choice");
                        //Accept and check choice
                        bool isValidChoice1 = int.TryParse(Console.ReadLine(), out choice1);
                        if (isValidChoice1)
                        {
                            switch (choice1)
                            {
                                case 1: await AddCarLoan(); break;
                                case 2: await UpdateCarLoan(); break;
                                case 3: await DeleteCarLoan(); break;
                                case 4: await ShowAllCarLoan(); break;
                                case 5:
                                    Console.WriteLine("Enter Status");
                                    string Status = Console.ReadLine();
                                    await SearchCarLoanByLoanStatus(Status); break;

                            }
                        }
                        else
                        {
                            choice1 = -2;
                        }
                    } while (choice1 != 0 && choice1 != -1);
                }

                if (Ch == 2)
                {
                    //Menu for Home Loan managment services
                    int choice2 = -2;
                    do
                    {
                        Console.WriteLine("\n***************Home Loan Services***********");

                        Console.WriteLine("1. Apply For Home Loan");
                        Console.WriteLine("2. Update Home Loan");
                        Console.WriteLine("3. Delete Home Loan");
                        Console.WriteLine("4. Show All Home Loan ");
                        Console.WriteLine("5. Search Home Loan By Loan Status");
                        Console.WriteLine("-1 For Exit");
                        Console.WriteLine("Enter Choice");

                        //Accept and check choice
                        bool isValidChoice2 = int.TryParse(Console.ReadLine(), out choice2);
                        if (isValidChoice2)
                        {
                            switch (choice2)
                            {

                                case 1: await AddHomeLoan(); break;
                                case 2: await UpdateHomeLoan(); break;
                                case 3: await DeleteHomeLoan(); break;
                                case 4: await ShowAllHomeLoan(); break;
                                case 5:
                                    Console.WriteLine("Enter Status");
                                    string Status1 = Console.ReadLine();
                                    await SearchHomeLoanByLoanStatus(Status1); break;
                            }
                        }
                        else
                        {
                            choice2 = -2;
                        }
                    } while (choice2 != 0 && choice2 != -1);
                }
                if (Ch == 3)
                {
                    //Menu for Education Loan managment services
                    int choice3 = -2;
                    do
                    {
                        Console.WriteLine("\n***************Education Loan Services***********");
                        Console.WriteLine("1. Apply For Education Loan");
                        Console.WriteLine("2. Update Education Loan");
                        Console.WriteLine("3. Delete Education Loan");
                        Console.WriteLine("4. Show All Education Loan ");
                        Console.WriteLine("5. Search Education Loan By Loan Status");
                        Console.WriteLine("-1 For Exit");
                        Console.WriteLine("Enter Choice");

                        //Accept and check choice
                        bool isValidChoice3 = int.TryParse(Console.ReadLine(), out choice3);
                        if (isValidChoice3)
                        {
                            switch (choice3)
                            {

                                case 1: await AddEducationLoan(); break;
                                case 2: await UpdateEducationLoan(); break;
                                case 3: await DeleteEducationLoan(); break;
                                case 4: await ShowAllEducationLoan(); break;
                                case 5:
                                    Console.WriteLine("Enter Status");
                                    string Status2 = Console.ReadLine();
                                    await SearchEducationLoanByLoanStatus(Status2); break;
                            }
                        }
                        else
                        {
                            choice3 = -2;
                        }

                    } while (choice3 != 0 && choice3 != -1);
                }
                if (Ch == 4)
                {
                    //Menu for Personal Loan managment services
                    int choice4 = -2;
                    do
                    {
                        Console.WriteLine("1. Apply For Personal Loan");
                        Console.WriteLine("2. Update Personal Loan");
                        Console.WriteLine("3. Delete Personal Loan");
                        Console.WriteLine("4. Show All Personal Loan ");
                        Console.WriteLine("5. Search Personal Loan By Loan Status");

                        Console.WriteLine("-1. Exit");
                        Console.WriteLine("Enter Choice");


                        //Accept and check choice
                        bool isValidChoice4 = int.TryParse(Console.ReadLine(), out choice4);
                        if (isValidChoice4)
                        {
                            switch (choice4)
                            {

                                case 1: await AddPersonalLoan(); break;
                                case 2: await UpdatePersonalLoan(); break;
                                case 3: await DeletePersonalLoan(); break;
                                case 4: await ShowAllPersonalLoan(); break;
                                case 5:
                                    Console.WriteLine("Enter Status");
                                    string Status3 = Console.ReadLine();
                                    await SearchPersonalLoanByLoanStatus(Status3); break;

                            }
                        }

                        else
                        {
                            choice4 = -2;



                        }
                    } while (choice4 != 0 && choice4 != -1);
                }
                if (Ch == 5)
                    await Serialize();

                
            } while (Ch != -1);
            return Ch;



            /// <summary>
            /// To Add new Car Loan By taking information from user
            /// </summary>
            /// <returns></returns>
            async Task AddCarLoan()
            {
                try
                {
                    //Read inputs
                    CarLoan carloan = new CarLoan();

                    Console.WriteLine("Enter Customer Number");
                    string customernumber = Console.ReadLine();
                    Console.WriteLine("Enter Loan Amount ");
                    carloan.AmtOfLoan = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Loan Duration in Years ");
                    carloan.Tenure = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Annual Income ");
                    carloan.YearlyIncome = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Years of  Experience");
                    carloan.YearsOfService = double.Parse(Console.ReadLine());
                    CustomerBL cbl = new CustomerBL();
                    Customer cust = await cbl.GetCustomerByCustomerNumberBL(customernumber);
                    if((carloan.AmtOfLoan)>cust.AnnualIncome*5)
                    {
                        carloan.LoanStatus = "Rejected";
                    }
                    else
                    {
                        carloan.LoanStatus = "Approved";
                    }

                    Console.WriteLine("License Number");
                    carloan.License = Console.ReadLine();



                    //Invoke AddCarLoanBL method to add
                    using (ICarLoanBL carloanBL = new CarLoanBL())
                    {
                        bool isAdded = await carloanBL.AddCarLoanBL(carloan,customernumber);
                        if (isAdded)
                        {
                            Console.WriteLine("Car Loan Added");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Updates Car Loan by replacing all existing information with new information
            /// </summary>
            /// <returns></returns>
            async Task UpdateCarLoan()
            {
                try
                {
                    //To Display list of car Loan
                    await ShowAllCarLoan();
                    using (ICarLoanBL carloanBL = new CarLoanBL())
                    {
                        //Read Serial Number of Updating Loan
                        Console.Write("Car Loan List #: ");
                        bool isNumberValid = int.TryParse(Console.ReadLine(), out int serial);
                        if (isNumberValid)
                        {
                            serial--;
                            List<CarLoan> carloanlist = await carloanBL.GetAllCarLoanBL();
                            if (serial <= carloanlist.Count - 1)
                            {
                                //Read inputs
                                CarLoan carloan = carloanlist[serial];
                                Console.WriteLine("Enter Loan Amount ");
                                carloan.AmtOfLoan = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Loan Duration ");
                                carloan.Tenure = float.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Annual Income ");
                                carloan.YearlyIncome = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Work Experience");
                                carloan.YearsOfService = double.Parse(Console.ReadLine());
                                Console.WriteLine("License Number ");
                                carloan.License = Console.ReadLine();


                                //Invoke UpdateCarLoanBL method to update
                                bool isUpdated = await carloanBL.UpdateCarLoanBL(carloan);
                                if (isUpdated)
                                {
                                    Console.WriteLine("CarLoan Updated");
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid CarLoan #.\nPlease enter a number between 1 to {carloanlist.Count}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Invalid number.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Delete CarLoan
            /// </summary>
            /// <returns></returns>
            async Task DeleteCarLoan()
            {
                try
                {
                    //To Display list Of All Car Loan  
                    await ShowAllCarLoan();
                    using (ICarLoanBL carloanBL = new CarLoanBL())
                    {
                        //Read Serial Number of Deleting Loan
                        Console.Write("Car Loan #: ");
                        bool isNumberValid = int.TryParse(Console.ReadLine(), out int serial);
                        if (isNumberValid)
                        {
                            serial--;
                            List<CarLoan> carloan = await carloanBL.GetAllCarLoanBL();
                            if (serial <= carloan.Count - 1)
                            {
                                //Confirmation
                                CarLoan cl = carloan[serial];
                                Console.Write("Are you sure? (Y/N): ");
                                string confirmation = Console.ReadLine();

                                if (confirmation.Equals("Y", StringComparison.OrdinalIgnoreCase))
                                {
                                    //Invoke DeleteCarLoanBL method to delete
                                    bool isDeleted = await carloanBL.DeleteCarLoanBL(cl.LoanID);
                                    if (isDeleted)
                                    {
                                        Console.WriteLine("Car Loan Deleted");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid Car Loan #.\nPlease enter a number between 1 to {carloan.Count}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Invalid number.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
            ///<summary>
            /// Displays list of All CarLoan.
            /// </summary>
            /// <returns></returns>
            async Task ShowAllCarLoan()
            {
                try
                {
                    using (ICarLoanBL carloanBL = new CarLoanBL())
                    {
                        //Get and display list of Car Loan.
                        List<CarLoan> carloanlist = await carloanBL.GetAllCarLoanBL();
                        Console.WriteLine("CAR LOAN LIST:");
                        if (carloanlist != null && carloanlist?.Count > 0)
                        {
                            Console.WriteLine("#\tLoanAmount\tloanStatus\tLoanType\tLoanduration\tLicense\t\tLoanApplyDate");
                            int serial = 0;
                            foreach (var carloan in carloanlist)
                            {
                                serial++;
                                Console.WriteLine($"{serial}\t{carloan.AmtOfLoan}\t\t{carloan.LoanStatus}\t\t{carloan.LoanType}\t\t{carloan.Tenure}\t\t{carloan.License}\t\t{carloan.LoanApplyDate}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// To Display List of Car loan Based on Loan Status 
            /// </summary>
            /// <param name="status"></param>
            /// <returns></returns>
            async Task SearchCarLoanByLoanStatus(string status)
            {
                try
                {
                    using (ICarLoanBL carloanBL = new CarLoanBL())
                    {
                        //Get and display list of Car Loan based on status.
                        List<CarLoan> carloanlist = await carloanBL.GetCarLoanByLoanStatusBL(status);
                        Console.WriteLine("CAR LOAN LIST:");
                        if (carloanlist != null && carloanlist?.Count > 0)
                        {
                            Console.WriteLine("#\tLoanAmount\tloanStatus\tLoanType\tLoanduration\tLicense\t\tLoanApplyDate");
                            int serial = 0;
                            foreach (var carloan in carloanlist)
                            {
                                serial++;
                                Console.WriteLine($"{serial}\t{carloan.AmtOfLoan}\t\t{carloan.LoanStatus}\t\t{carloan.LoanType}\t\t{carloan.Tenure}\t\t{carloan.License}\t\t{carloan.LoanApplyDate}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Method to Add Home Loan by taking information from user  
            /// </summary>
            /// <returns></returns>
            async Task AddHomeLoan()
            {
                try
                {
                    //Read inputs
                    HomeLoan homeloan = new HomeLoan();

                    Console.WriteLine("Enter Loan Amount ");
                    homeloan.AmtOfLoan = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Loan Duration ");
                    homeloan.Tenure = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Annual Income ");
                    homeloan.YearlyIncome = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Work Experience");
                    homeloan.YearsOfService = double.Parse(Console.ReadLine());
                    homeloan.LoanStatus = "Pending";
                    Console.WriteLine("Collateral Value ");
                    homeloan.Collateral = double.Parse(Console.ReadLine());



                    //Invoke AddHomeLoanBL method to add
                    using (IHomeLoanBL homeloanBL = new HomeLoanBL())
                    {
                        bool isAdded = await homeloanBL.AddHomeLoanBL(homeloan);
                        if (isAdded)
                        {
                            Console.WriteLine("Home Loan Added");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Update Home Loan
            /// </summary>
            /// <returns></returns>
            async Task UpdateHomeLoan()
            {
                try
                {
                    await ShowAllHomeLoan();
                    using (IHomeLoanBL homeloanBL = new HomeLoanBL())
                    {
                        //Read Serial Number
                        Console.Write("Home Loan List #: ");
                        bool isNumberValid = int.TryParse(Console.ReadLine(), out int serial);
                        if (isNumberValid)
                        {
                            serial--;
                            List<HomeLoan> homeloanlist = await homeloanBL.GetAllHomeLoanBL();
                            if (serial <= homeloanlist.Count - 1)
                            {
                                //Read inputs
                                HomeLoan homeloan = homeloanlist[serial];

                                Console.WriteLine("Enter Loan Amount ");
                                homeloan.AmtOfLoan = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Loan Duration ");
                                homeloan.Tenure = float.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Annual Income ");
                                homeloan.YearlyIncome = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Work Experience");

                                homeloan.LoanType = Console.ReadLine();
                                Console.WriteLine("Collateral Value ");
                                homeloan.Collateral = double.Parse(Console.ReadLine());


                                //Invoke UpdateHomeLoanBL method to update
                                bool isUpdated = await homeloanBL.UpdateHomeLoanBL(homeloan);
                                if (isUpdated)
                                {
                                    Console.WriteLine("HomeLoan Updated");
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid HomeLoan #.\nPlease enter a number between 1 to {homeloanlist.Count}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Invalid number.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Delete CarLoan
            /// </summary>
            /// <returns></returns>
            async Task DeleteHomeLoan()
            {
                try
                {
                    await ShowAllHomeLoan();
                    using (IHomeLoanBL homeloanBL = new HomeLoanBL())
                    {
                        //Read Serial Number
                        Console.Write("Home Loan List #: ");
                        bool isNumberValid = int.TryParse(Console.ReadLine(), out int serial);
                        if (isNumberValid)
                        {
                            serial--;
                            List<HomeLoan> homeloan = await homeloanBL.GetAllHomeLoanBL();
                            if (serial <= homeloan.Count - 1)
                            {
                                //Confirmation
                                HomeLoan hl = homeloan[serial];
                                Console.Write("Are you sure? (Y/N): ");
                                string confirmation = Console.ReadLine();

                                if (confirmation.Equals("Y", StringComparison.OrdinalIgnoreCase))
                                {
                                    //Invoke DeleteHomeLoanBL method to delete
                                    bool isDeleted = await homeloanBL.DeleteHomeLoanBL(hl.LoanID);
                                    if (isDeleted)
                                    {
                                        Console.WriteLine("Home Loan Deleted");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid Supplier #.\nPlease enter a number between 1 to {homeloan.Count}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Invalid number.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// Displays list of HomeLoan.
            /// </summary>
            /// <returns></returns>
            async Task ShowAllHomeLoan()
            {
                try
                {
                    using (IHomeLoanBL homeloanBL = new HomeLoanBL())
                    {
                        //Get and display list of Home Loan.
                        List<HomeLoan> homeloanlist = await homeloanBL.GetAllHomeLoanBL();
                        Console.WriteLine("HOME LOAN LIST:");
                        if (homeloanlist != null && homeloanlist?.Count > 0)
                        {
                            Console.WriteLine("#\tLoanAmount\tloanStatus\tLoanType\tLoanduration\tCollateral\t\tLoanApplyDate");
                            int serial = 0;
                            foreach (var loan in homeloanlist)
                            {
                                serial++;
                                Console.WriteLine($"{serial}\t{loan.AmtOfLoan}\t\t{loan.LoanStatus}\t\t{loan.LoanType}\t\t{loan.Tenure}\t\t{loan.Collateral}\\tt{loan.LoanApplyDate}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// To Search all Home loan based on Approved , Pending and Rejected status
            /// </summary>
            /// <param name="status"></param>
            /// <returns></returns>
            async Task SearchHomeLoanByLoanStatus(string status)
            {
                try
                {
                    using (IHomeLoanBL homeloanBL = new HomeLoanBL())
                    {
                        //Get and display list of system users.
                        List<HomeLoan> homeloanlist = await homeloanBL.GetHomeLoanByLoanStatusBL(status);
                        Console.WriteLine("HOME LOAN LIST:");
                        if (homeloanlist != null && homeloanlist?.Count > 0)
                        {
                            Console.WriteLine("#\tLoanID\tLoanAmount\tloanStatus\tLoanType\tLoanduration\tCollateral\t\tLoanApplyDate");
                            int serial = 0;
                            foreach (var loan in homeloanlist)
                            {
                                serial++;
                                Console.WriteLine($"{serial}\t{loan.AmtOfLoan}\t\t{loan.LoanStatus}\t\t{loan.LoanType}\t\t{loan.Tenure}\t\t{loan.Collateral}\t\t{loan.LoanApplyDate}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            //Education Loan
            /// <summary>
            /// To Add New Education By taking information from User
            /// </summary>
            /// <returns></returns>
            async Task AddEducationLoan()
            {
                try
                {
                    //Read inputs
                    EducationLoan eduloan = new EducationLoan();


                    Console.WriteLine("Enter Loan Amount ");
                    eduloan.AmtOfLoan = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Loan Duration ");
                    eduloan.Tenure = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Annual Income ");
                    eduloan.YearlyIncome = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Work Experience");
                    eduloan.YearsOfService = double.Parse(Console.ReadLine());

                    Console.WriteLine("College Name  ");
                    eduloan.CollegeName = Console.ReadLine();
                    Console.WriteLine(" Sponseror ");
                    eduloan.Sponseror = Console.ReadLine();
                    Console.WriteLine("Enter Collateral ");
                    eduloan.Collateral = double.Parse(Console.ReadLine());
                    Console.WriteLine("Admission ID ");
                    eduloan.AdmissionID = Console.ReadLine();



                    //Invoke AddEducationLoanBL method to add
                    using (IEducationLoanBL eduloanBL = new EducationLoanBL())
                    {
                        bool isAdded = await eduloanBL.AddEducationLoanBL(eduloan);
                        if (isAdded)
                        {
                            Console.WriteLine("Education Loan Added");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Updates Education Loan.
            /// </summary>
            /// <returns></returns>
            async Task UpdateEducationLoan()
            {
                try
                {
                    await ShowAllEducationLoan();
                    using (IEducationLoanBL eduloanBL = new EducationLoanBL())
                    {
                        //Read Serial Number
                        Console.Write("Education Loan List #: ");
                        bool isNumberValid = int.TryParse(Console.ReadLine(), out int serial);
                        if (isNumberValid)
                        {
                            serial--;
                            List<EducationLoan> eduloanlist = await eduloanBL.GetAllEducationLoanBL();
                            if (serial <= eduloanlist.Count - 1)
                            {
                                //Read inputs
                                EducationLoan eduloan = eduloanlist[serial];
                                Console.WriteLine("Enter Loan Amount ");
                                eduloan.AmtOfLoan = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Loan Duration ");
                                eduloan.Tenure = float.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Annual Income ");
                                eduloan.YearlyIncome = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Work Experience");
                                eduloan.YearsOfService = double.Parse(Console.ReadLine());
                                Console.WriteLine("College Name  ");
                                eduloan.CollegeName = Console.ReadLine();
                                Console.WriteLine(" Sponseror ");
                                eduloan.Sponseror = Console.ReadLine();
                                Console.WriteLine("Enter Collateral ");
                                eduloan.Collateral = double.Parse(Console.ReadLine());
                                Console.WriteLine("Admission ID ");
                                eduloan.AdmissionID = Console.ReadLine();



                                //Invoke UpdateEducationLoanBL method to update
                                bool isUpdated = await eduloanBL.UpdateEducationLoanBL(eduloan);
                                if (isUpdated)
                                {
                                    Console.WriteLine("Education Loan Updated");
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid EducationLoan #.\nPlease enter a number between 1 to {eduloanlist.Count}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Invalid number.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Delete CarLoan
            /// </summary>
            /// <returns></returns>
            async Task DeleteEducationLoan()
            {
                try
                {
                    await ShowAllEducationLoan();
                    using (IEducationLoanBL eduloanBL = new EducationLoanBL())
                    {
                        //Read Serial Number
                        Console.Write("Education Loan #: ");
                        bool isNumberValid = int.TryParse(Console.ReadLine(), out int serial);
                        if (isNumberValid)
                        {
                            serial--;
                            List<EducationLoan> eduloan = await eduloanBL.GetAllEducationLoanBL();
                            if (serial <= eduloan.Count - 1)
                            {
                                //Confirmation
                                EducationLoan cl = eduloan[serial];
                                Console.Write("Are you sure? (Y/N): ");
                                string confirmation = Console.ReadLine();

                                if (confirmation.Equals("Y", StringComparison.OrdinalIgnoreCase))
                                {
                                    //Invoke DeleteEducationBL method to delete
                                    bool isDeleted = await eduloanBL.DeleteEducationLoanBL(cl.LoanID);
                                    if (isDeleted)
                                    {
                                        Console.WriteLine("Education Loan Deleted");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid Education #.\nPlease enter a number between 1 to {eduloan.Count}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Invalid number.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
            ///<summary>
            /// Displays list of Education Loan.
            /// </summary>
            /// <returns></returns>
            async Task ShowAllEducationLoan()
            {
                try
                {
                    using (IEducationLoanBL carloanBL = new EducationLoanBL())
                    {
                        //Get and display list of Education Loan.
                        List<EducationLoan> eduloanlist = await carloanBL.GetAllEducationLoanBL();
                        Console.WriteLine("EDUCATION LOAN LIST:");
                        if (eduloanlist != null && eduloanlist?.Count > 0)
                        {
                            Console.WriteLine("#\tLoanAmount\tloanStatus\tLoanType\tLoanduration\tCollegeName\tLoanApplyDate\tSponseror");
                            int serial = 0;
                            foreach (var loan in eduloanlist)
                            {
                                serial++;
                                Console.WriteLine($"{serial}\t\t{loan.AmtOfLoan}\t{loan.LoanStatus}\t\t{loan.LoanType}\t{loan.Tenure}\t{loan.CollegeName}\t{loan.LoanApplyDate}\t{loan.Sponseror}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// To display List of all Education Loan Based on Status
            /// </summary>
            /// <param name="status"></param>
            /// <returns></returns>
            async Task SearchEducationLoanByLoanStatus(string status)
            {
                try
                {
                    using (IEducationLoanBL eduloanBL = new EducationLoanBL())
                    {
                        //Get and display list of Education Loan.
                        List<EducationLoan> eduloanlist = await eduloanBL.GetEducationLoanByLoanStatusBL(status);
                        Console.WriteLine("EDUCATION LOAN LIST:");
                        if (eduloanlist != null && eduloanlist?.Count > 0)
                        {
                            Console.WriteLine("#\tLoanAmount\tloanStatus\tLoanType\tLoanduration\tCollegeName\tLoanApplyDate\tSponseror");
                            int serial = 0;
                            foreach (var loan in eduloanlist)
                            {
                                serial++;
                                Console.WriteLine($"{serial}\t\t{loan.AmtOfLoan}\t{loan.LoanStatus}\t\t{loan.LoanType}\t{loan.Tenure}\t{loan.CollegeName}\t{loan.LoanApplyDate}\t{loan.Sponseror}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// To add new personal Loan based on user information
            /// </summary>
            /// <returns></returns>
            async Task AddPersonalLoan()
            {
                try
                {
                    //Read inputs
                    PersonalLoan perloan = new PersonalLoan();

                    Console.WriteLine("Enter Loan Amount ");
                    perloan.AmtOfLoan = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Loan Duration ");
                    perloan.Tenure = float.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Annual Income ");
                    perloan.YearlyIncome = double.Parse(Console.ReadLine());
                    Console.WriteLine("Enter Work Experience");
                    perloan.YearsOfService = double.Parse(Console.ReadLine());

                    Console.WriteLine("Collateral Value ");
                    perloan.Collateral = double.Parse(Console.ReadLine());



                    //Invoke AddPersonalLoanBL method to add
                    using (IPersonalLoanBL perloanBL = new PersonalLoanBL())
                    {
                        bool isAdded = await perloanBL.AddPersonalLoanBL(perloan);
                        if (isAdded)
                        {
                            Console.WriteLine("Personal Loan Added");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Updates Personal Loan.
            /// </summary>
            /// <returns></returns>
            async Task UpdatePersonalLoan()
            {
                try
                {
                    await ShowAllPersonalLoan();
                    using (IPersonalLoanBL perloanBL = new PersonalLoanBL())
                    {
                        //Read Serial Number
                        Console.Write("Personal Loan List #: ");
                        bool isNumberValid = int.TryParse(Console.ReadLine(), out int serial);
                        if (isNumberValid)
                        {
                            serial--;
                            List<PersonalLoan> perloanlist = await perloanBL.GetAllPersonalLoanBL();
                            if (serial <= perloanlist.Count - 1)
                            {
                                //Read inputs
                                PersonalLoan perloan = perloanlist[serial];

                                Console.WriteLine("Enter Loan Amount ");
                                perloan.AmtOfLoan = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Loan Duration ");
                                perloan.Tenure = float.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Annual Income ");
                                perloan.YearlyIncome = double.Parse(Console.ReadLine());
                                Console.WriteLine("Enter Work Experience");
                                perloan.YearsOfService = double.Parse(Console.ReadLine());

                                Console.WriteLine("Collateral Value ");
                                perloan.Collateral = double.Parse(Console.ReadLine());


                                //Invoke UpdatePersonalLoanBL method to update
                                bool isUpdated = await perloanBL.UpdatePersonalLoanBL(perloan);
                                if (isUpdated)
                                {
                                    Console.WriteLine("PersonalLoan Updated");
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid PersonalLoan #.\nPlease enter a number between 1 to {perloanlist.Count}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Invalid number.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }

            /// <summary>
            /// Delete PersonalLoan
            /// </summary>
            /// <returns></returns>
            async Task DeletePersonalLoan()
            {
                try
                {
                    using (IPersonalLoanBL perloanBL = new PersonalLoanBL())
                    {
                        //Read Serial Number
                        Console.Write("Personal loan list #: ");
                        bool isNumberValid = int.TryParse(Console.ReadLine(), out int serial);
                        if (isNumberValid)
                        {
                            serial--;
                            List<PersonalLoan> perloan = await perloanBL.GetAllPersonalLoanBL();
                            if (serial <= perloan.Count - 1)
                            {
                                //Confirmation
                                PersonalLoan hl = perloan[serial];
                                Console.Write("Are you sure? (Y/N): ");
                                string confirmation = Console.ReadLine();

                                if (confirmation.Equals("Y", StringComparison.OrdinalIgnoreCase))
                                {
                                    //Invoke DeletePersonalLoanBL method to delete
                                    bool isDeleted = await perloanBL.DeleteLoanBL(hl.LoanID);
                                    if (isDeleted)
                                    {
                                        Console.WriteLine("Personal Loan Deleted");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine($"Invalid Personal Loan #.\nPlease enter a number between 1 to {perloan.Count}");
                            }
                        }
                        else
                        {
                            Console.WriteLine($"Invalid number.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
            ///<summary>
            /// Displays list of Personal Loan.
            /// </summary>
            /// <returns></returns>
            async Task ShowAllPersonalLoan()
            {
                try
                {
                    using (IPersonalLoanBL perloanBL = new PersonalLoanBL())
                    {
                        //Get and display list of Personal Loan.
                        List<PersonalLoan> perloanlist = await perloanBL.GetAllPersonalLoanBL();
                        Console.WriteLine("PERSONAL LOAN LIST:");
                        if (perloanlist != null && perloanlist?.Count > 0)
                        {
                            Console.WriteLine("#\tLoanAmount\tloanStatus\tLoanType\tLoanduration\tCollateral\t\tLoanApplyDate");
                            int serial = 0;
                            foreach (var loan in perloanlist)
                            {
                                serial++;
                                Console.WriteLine($"{serial}\t{loan.AmtOfLoan}\t\t{loan.LoanStatus}\t\t{loan.LoanType}\t\t{loan.Tenure}\t\t{loan.Collateral}\t\t{loan.LoanApplyDate}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
            /// <summary>
            /// To Display List Of Loan based on Status
            /// </summary>
            /// <param name="status"></param>
            /// <returns></returns>
            async Task SearchPersonalLoanByLoanStatus(string status)
            {
                try
                {
                    using (IPersonalLoanBL perloanBL = new PersonalLoanBL())
                    {
                        //Get and display list of personal loan based on status.
                        List<PersonalLoan> perloanlist = await perloanBL.GetPersonalLoanByLoanStatusBL(status);
                        Console.WriteLine("PERSONAL LOAN LIST:");
                        if (perloanlist != null && perloanlist?.Count > 0)
                        {
                            Console.WriteLine("#LoanAmount\tloanStatus\tLoanType\tLoanduration\tCollateral\tLoanApplyDate");
                            int serial = 0;
                            foreach (var loan in perloanlist)
                            {
                                serial++;
                                Console.WriteLine($"{serial}\t{loan.AmtOfLoan}\t\t{loan.LoanStatus}\t\t{loan.LoanType}\t\t{loan.Tenure}\t\t{loan.Collateral}\t\t{loan.LoanApplyDate}");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
            async Task Serialize()
            {
                try
                {
                    CarLoanBL cbl = new CarLoanBL();
                    await cbl.CarSerialize();
                    HomeLoanBL hbl = new HomeLoanBL();
                    await hbl.HomeSerialize();
                    PersonalLoanBL pbl = new PersonalLoanBL();
                    await pbl.PersonalSerialize();
                    EducationLoanBL ebl = new EducationLoanBL();
                    await ebl.EducationSerialize();
                    Console.WriteLine("Sucessfully Serialized");
                }
                catch (Exception ex)
                {
                    ExceptionLogger.LogException(ex);
                    Console.WriteLine(ex.Message);
                }
            }
        }
    }
}

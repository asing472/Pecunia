﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    public class CurrentAccountBL
    {
        private static bool ValidateCurrentAccount(CurrentAccount account)
        {
            StringBuilder sb = new StringBuilder();
            bool validCurrentAccount = true;
            if (account.Balance < account.MinimumBalance)
            {
                validCurrentAccount = false;
                sb.Append(Environment.NewLine + "Account balance can't be less than minimum balance");

            }
            if (account.MinimumBalance < 0)
            {
                validCurrentAccount = false;
                sb.Append(Environment.NewLine + "Minimum balance can't be zero");

            }
            if (account.StartDate == DateTime.MinValue) 
            {
                validCurrentAccount = false;
                sb.Append(Environment.NewLine + "StartDate can't be null");

            }
            if ((account.AccountType != "Savings")&&(account.AccountType != "Current")&&(account.AccountType != "Fixed"))
            {
                validCurrentAccount = false;
                sb.Append(Environment.NewLine + "AccountType can be Savings or Current or Fixed");

            }

            if (validCurrentAccount == false)
                throw new PecuniaException(sb.ToString());
            return validCurrentAccount;
        }

        public static bool CreateCurrentAccountBL(CurrentAccount newAccount)
        {
            bool CurrentAccountCreated = false;
            try
            {
                if (ValidateCurrentAccount(newAccount))
                {
                    CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                    CurrentAccountCreated = accountDAL.CreateCurrentAccountDAL(newAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CurrentAccountCreated;
        }

        public static List<CurrentAccount> GetAllCurrentAccountsBL()
        {
            List<CurrentAccount> CurrentAccountList = null;
            try
            {
                CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                CurrentAccountList = accountDAL.GetAllCurrentAccountsDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return CurrentAccountList;
        }

        public static CurrentAccount SearchCurrentAccountBL(string searchAccountNo)
        {
            CurrentAccount searchCurrentAccount = null;
            try
            {
                CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                searchCurrentAccount = accountDAL.SearchCurrentAccountDAL(searchAccountNo);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchCurrentAccount;

        }

        public static bool UpdateCurrentAccountBL(CurrentAccount updateAccount)
        {
            bool CurrentAccountUpdated = false;
            try
            {
                if (ValidateCurrentAccount(updateAccount))
                {
                    CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                    CurrentAccountUpdated = accountDAL.UpdateCurrentAccountDAL(updateAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CurrentAccountUpdated;
        }

        public static bool DeleteCurrentAccountBL(string deleteAccountNo)
        {
            bool CurrentAccountDeleted = false;
            try
            {
                Regex rgx = new Regex(@"^[1]{1}[0-9]{9}$");

                if (rgx.IsMatch(deleteAccountNo) == true)
                {
                    CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                    CurrentAccountDeleted = accountDAL.DeleteCurrentAccountDAL(deleteAccountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return CurrentAccountDeleted;
        }
       
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    public class FixedAccountBL
    {
        private static bool ValidateFixedAccount(FixedAccount account)
        {
            StringBuilder sb = new StringBuilder();
            bool validFixedAccount = true;
            if (account.Balance < account.MinimumBalance)
            {
                validFixedAccount = false;
                sb.Append(Environment.NewLine + "Account balance can't be less than minimum balance");

            }
            if (account.MinimumBalance < 0)
            {
                validFixedAccount = false;
                sb.Append(Environment.NewLine + "Minimum balance can't be zero");

            }
            if (account.Tenure< 0)
            {
                validFixedAccount = false;
                sb.Append(Environment.NewLine + "Tenure can't be negative");

            }
            if (account.StartDate == DateTime.MinValue)
            {
                validFixedAccount = false;
                sb.Append(Environment.NewLine + "StartDate can't be null");

            }
            if ((account.AccountType != "Savings") && (account.AccountType != "Fixed") && (account.AccountType != "Fixed"))
            {
                validFixedAccount = false;
                sb.Append(Environment.NewLine + "AccountType can be Savings or Fixed or Fixed");

            }


            if (validFixedAccount == false)
                throw new PecuniaException(sb.ToString());
            return validFixedAccount;
        }

        public static bool CreateFixedAccountBL(FixedAccount newAccount)
        {
            bool FixedAccountCreated = false;
            try
            {
                if (ValidateFixedAccount(newAccount))
                {
                    FixedAccountDAL accountDAL = new FixedAccountDAL();
                    FixedAccountCreated = accountDAL.CreateFixedAccountDAL(newAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return FixedAccountCreated;
        }

        public static List<FixedAccount> GetAllFixedAccountsBL()
        {
            List<FixedAccount> FixedAccountList = null;
            try
            {
                FixedAccountDAL accountDAL = new FixedAccountDAL();
                FixedAccountList = accountDAL.GetAllFixedAccountsDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return FixedAccountList;
        }

        public static FixedAccount SearchFixedAccountBL(string searchAccountNo)
        {
            FixedAccount searchFixedAccount = null;
            try
            {
                FixedAccountDAL accountDAL = new FixedAccountDAL();
                searchFixedAccount = accountDAL.SearchFixedAccountDAL(searchAccountNo);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchFixedAccount;

        }

        public static bool UpdateFixedAccountBL(FixedAccount updateAccount)
        {
            bool FixedAccountUpdated = false;
            try
            {
                if (ValidateFixedAccount(updateAccount))
                {
                    FixedAccountDAL accountDAL = new FixedAccountDAL();
                    FixedAccountUpdated = accountDAL.UpdateFixedAccountDAL(updateAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return FixedAccountUpdated;
        }

        public static bool DeleteFixedAccountBL(string deleteAccountNo)
        {
            bool FixedAccountDeleted = false;
            try
            {
                Regex rgx = new Regex(@"^[1]{1}[0-9]{9}$");

                if (rgx.IsMatch(deleteAccountNo) == true)
                {
                    FixedAccountDAL accountDAL = new FixedAccountDAL();
                    FixedAccountDeleted = accountDAL.DeleteFixedAccountDAL(deleteAccountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return FixedAccountDeleted;
        }

    }
}

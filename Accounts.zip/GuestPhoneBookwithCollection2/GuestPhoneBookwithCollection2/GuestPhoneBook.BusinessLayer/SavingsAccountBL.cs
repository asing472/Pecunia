﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    public class SavingsAccountBL
    {
        private static bool ValidateSavingsAccount(SavingsAccount account)
        {
            StringBuilder sb = new StringBuilder();
            bool validSavingsAccount = true;
            if (account.Balance < account.MinimumBalance)
            {
                validSavingsAccount = false;
                sb.Append(Environment.NewLine + "Account balance can't be less than minimum balance");

            }
            if (account.MinimumBalance < 0)
            {
                validSavingsAccount = false;
                sb.Append(Environment.NewLine + "Minimum balance can't be zero");

            }
            if (account.StartDate == DateTime.MinValue)
            {
                validSavingsAccount = false;
                sb.Append(Environment.NewLine + "StartDate can't be null");

            }
            if ((account.AccountType != "Savings") && (account.AccountType != "Current") && (account.AccountType != "Fixed"))
            {
                validSavingsAccount = false;
                sb.Append(Environment.NewLine + "AccountType can be Savings or Current or Fixed");

            }

            if (validSavingsAccount == false)
                throw new PecuniaException(sb.ToString());
            return validSavingsAccount;
        }

        public static bool CreateSavingsAccountBL(SavingsAccount newAccount)
        {
            bool accountCreated = false;
            try
            {
                if (ValidateSavingsAccount(newAccount))
                {
                    SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                    accountCreated = accountDAL.CreateSavingsAccountDAL(newAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return accountCreated;
        }

        public static List<SavingsAccount> GetAllSavingsAccountsBL()
        {
            List<SavingsAccount> SavingsAccountList = null;
            try
            {
                SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                SavingsAccountList = accountDAL.GetAllSavingsAccountsDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return SavingsAccountList;
        }

        public static SavingsAccount SearchSavingsAccountBL(string searchAccountNo)
        {
            SavingsAccount searchAccount = null;
            try
            {
                SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                searchAccount = accountDAL.SearchSavingsAccountDAL(searchAccountNo);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchAccount;

        }

        public static List<SavingsAccount> GetSavingsAccountsByCustomerIDBL(string searchcustomerID)
        {
            List<SavingsAccount> accountsbyCustID = null;
            try
            {
                SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                accountsbyCustID = accountDAL.GetSavingsAccountsByCustomerIDDAL(searchcustomerID);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyCustID;

        }

        public static List<SavingsAccount> GetSavingsAccountsByCustomerNameBL(string searchcustomerName)
        {
            List<SavingsAccount> accountsbyCustomerName = null;
            try
            {
                SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                accountsbyCustomerName = accountDAL.GetSavingsAccountsByCustomerNameDAL(searchcustomerName);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyCustomerName;

        }


        public static bool UpdateSavingsAccountBL(SavingsAccount updateAccount)
        {
            bool SavingsAccountUpdated = false;
            try
            {
                if (ValidateSavingsAccount(updateAccount))
                {
                    SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                    SavingsAccountUpdated = accountDAL.UpdateSavingsAccountDAL(updateAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return SavingsAccountUpdated;
        }


        public static bool DeleteSavingsAccountBL(string deleteAccountNo)
        {
            bool SavingsAccountDeleted = false;
            try
            {
                Regex rgx = new Regex(@"^[1]{1}[0-9]{9}$");

                if (rgx.IsMatch(deleteAccountNo) == true)
                {
                    SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                    SavingsAccountDeleted = accountDAL.DeleteSavingsAccountDAL(deleteAccountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return SavingsAccountDeleted;
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Pecunia.Entities;
using Pecunia.Exceptions;

namespace Pecunia.DataAccessLayer
{
    public class CurrentAccountDAL
    {
        public static List<CurrentAccount> CurrentAccountList = new List<CurrentAccount>();

        public bool CreateCurrentAccountDAL(CurrentAccount newAccount)
        {
            bool CurrentAccountCreated = false;
            try
            {
                CurrentAccountList.Add(newAccount);
                CurrentAccountCreated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return CurrentAccountCreated;

        }

        //List of all current accounts
        public List<CurrentAccount> GetAllCurrentAccountsDAL()
        {
            return CurrentAccountList;
        }
        //searching current accounts by accountno
        public CurrentAccount SearchCurrentAccountDAL(string searchAccountNo)
        {
            CurrentAccount searchCurrentAccount = null;
            try
            {
                foreach (CurrentAccount item in CurrentAccountList)
                {
                    if (item.AccountNo == searchAccountNo)
                    {
                        searchCurrentAccount = item;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchCurrentAccount;
        }

        //searching current accounts by customerID
        public List<CurrentAccount> GetCurrentAccountsByCustomerIDDAL(string searchcustomerID)
        {
            List<CurrentAccount> CurrentAccountsByCustID = new List<CurrentAccount>();
            try
            {
                foreach (CurrentAccount item in CurrentAccountList)
                {
                    if (item.CustomerID == searchcustomerID)
                    {
                        CurrentAccountsByCustID.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return CurrentAccountsByCustID;
        }

        //searching accounts by customerName
        public List<CurrentAccount> GetCurrentAccountsByCustomerNameDAL(string searchcustomerName)
        {
            List<CurrentAccount> CurrentAccountsbyCustomerName = new List<CurrentAccount>();
            try
            {
                foreach (CurrentAccount item in CurrentAccountList)
                {
                    if (item.CustomerName == searchcustomerName)
                    {
                        CurrentAccountsbyCustomerName.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return CurrentAccountsbyCustomerName;
        }

        //Get Balance
        public double GetBalance(string accountNumber)
        {
            double balance = 0;
            foreach (CurrentAccount item in CurrentAccountList)
            {
                if (item.AccountNo == accountNumber)
                {
                    balance = item.Balance;
                }
            }
            return balance;
        }
        //Update Balance
        public double UpdateBalance(string accountNumber, double balance)
        {

            foreach (CurrentAccount item in CurrentAccountList)
            {
                if (item.AccountNo == accountNumber)
                {
                    item.Balance = balance;
                }
            }
            return balance;
        }

        //Updating or modifying account details
        public bool UpdateCurrentAccountDAL(CurrentAccount updateAccount)
        {
            bool CurrentAccountUpdated = false;
            try
            {
                for (int i = 0; i < CurrentAccountList.Count; i++)
                {
                    if (CurrentAccountList[i].AccountNo == updateAccount.AccountNo)
                    {
                        CurrentAccountList[i].CustomerName = updateAccount.CustomerName;
                        CurrentAccountList[i].Phone = updateAccount.Phone;
                        CurrentAccountList[i].EmailID = updateAccount.EmailID;
                        CurrentAccountList[i].Address = updateAccount.Address;
                        CurrentAccountList[i].AccountType = updateAccount.AccountType;
                        CurrentAccountList[i].MinimumBalance = updateAccount.MinimumBalance;
                        CurrentAccountList[i].InterestRate = updateAccount.InterestRate;
                        CurrentAccountList[i].Branch = updateAccount.Branch;
                        CurrentAccountUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return CurrentAccountUpdated;

        }

        public bool DeleteCurrentAccountDAL(string deleteAccountNo)
        {
            bool CurrentAccountDeleted = false;
            try
            {
                CurrentAccount deleteAccount = null;
                foreach (CurrentAccount item in CurrentAccountList)
                {
                    if (item.AccountNo == deleteAccountNo)
                    {
                        deleteAccount = item;
                    }

                    /*
                     item.Status = "Closed";
                     

                     */
                     
                     
                }

                if (deleteAccountNo != null)
                {
                    CurrentAccountList.Remove(deleteAccount);
                    CurrentAccountDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return CurrentAccountDeleted;

        }

    }
}

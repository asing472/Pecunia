﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Pecunia.Entities;
using Pecunia.Exceptions;

namespace Pecunia.DataAccessLayer
{
    public class FixedAccountDAL
    {
        public static List<FixedAccount> FixedAccountList = new List<FixedAccount>();

        public bool CreateFixedAccountDAL(FixedAccount newAccount)
        {
            bool FixedAccountCreated = false;
            try
            {
                FixedAccountList.Add(newAccount);
                FixedAccountCreated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return FixedAccountCreated;

        }

        public List<FixedAccount> GetAllFixedAccountsDAL()
        {
            return FixedAccountList;
        }

        public FixedAccount SearchFixedAccountDAL(string searchAccountNo)
        {
            FixedAccount searchFixedAccount = null;
            try
            {
                foreach (FixedAccount item in FixedAccountList)
                {
                    if (item.AccountNo == searchAccountNo)
                    {
                        searchFixedAccount = item;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchFixedAccount;
        }

        //searching accounts by customerID
        public List<FixedAccount> GetFixedAccountsByCustomerIDDAL(string searchcustomerID)
        {
            List<FixedAccount> FixedAccountsByCustID = new List<FixedAccount>();
            try
            {
                foreach (FixedAccount item in FixedAccountList)
                {
                    if (item.CustomerID == searchcustomerID)
                    {
                        FixedAccountsByCustID.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return FixedAccountsByCustID;
        }

        //searching accounts by customerName
        public List<FixedAccount> GetFixedAccountsByCustomerNameDAL(string searchcustomerName)
        {
            List<FixedAccount> FixedAccountsbyCustomerName = new List<FixedAccount>();
            try
            {
                foreach (FixedAccount item in FixedAccountList)
                {
                    if (item.CustomerName == searchcustomerName)
                    {
                        FixedAccountsbyCustomerName.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return FixedAccountsbyCustomerName;
        }

        //Get Balance
        public double GetBalance(string accountNumber)
        {
            double balance = 0;
            foreach (FixedAccount item in FixedAccountList)
            {
                if (item.AccountNo == accountNumber)
                {
                    balance = item.Balance;
                }
            }
            return balance;
        }
        //Update Balance
        public double UpdateBalance(string accountNumber, double balance)
        {

            foreach (FixedAccount item in FixedAccountList)
            {
                if (item.AccountNo == accountNumber)
                {
                    item.Balance = balance;
                }
            }
            return balance;
        }


        //Updating or modifying account details
        public bool UpdateFixedAccountDAL(FixedAccount updateAccount)
        {
            bool FixedAccountUpdated = false;
            try
            {
                for (int i = 0; i < FixedAccountList.Count; i++)
                {
                    if (FixedAccountList[i].AccountNo == updateAccount.AccountNo)
                    {
                        FixedAccountList[i].CustomerName = updateAccount.CustomerName;
                        FixedAccountList[i].Phone = updateAccount.Phone;
                        FixedAccountList[i].EmailID = updateAccount.EmailID;
                        FixedAccountList[i].Address = updateAccount.Address;
                        FixedAccountList[i].AccountType = updateAccount.AccountType;
                        FixedAccountList[i].MinimumBalance = updateAccount.MinimumBalance;
                        FixedAccountList[i].InterestRate = updateAccount.InterestRate;
                        FixedAccountList[i].Branch = updateAccount.Branch;
                        FixedAccountList[i].Tenure = updateAccount.Tenure;
                        FixedAccountUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return FixedAccountUpdated;

        }

        public bool DeleteFixedAccountDAL(string deleteAccountNo)
        {
            bool FixedAccountDeleted = false;
            try
            {
                FixedAccount deleteAccount = null;
                foreach (FixedAccount item in FixedAccountList)
                {
                    if (item.AccountNo == deleteAccountNo)
                    {
                        deleteAccount = item;
                    }

                    /*
                     item.Status = "Closed";
                     

                     */


                }

                if (deleteAccountNo != null)
                {
                    FixedAccountList.Remove(deleteAccount);
                    FixedAccountDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return FixedAccountDeleted;

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Pecunia.Entities;
using Pecunia.Exceptions;

namespace Pecunia.DataAccessLayer
{
    public class SavingsAccountDAL
    {
        public static List<SavingsAccount> SavingsAccountList = new List<SavingsAccount>();

        public bool CreateSavingsAccountDAL(SavingsAccount newAccount)
        {
            bool SavingsAccountCreated = false;
            try
            {
                SavingsAccountList.Add(newAccount);
                SavingsAccountCreated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return SavingsAccountCreated;

        }

        public List<SavingsAccount> GetAllSavingsAccountsDAL()
        {
            return SavingsAccountList;
        }

        public SavingsAccount SearchSavingsAccountDAL(string searchAccountNo)
        {
            SavingsAccount searchSavingsAccount = null;
            try
            {
                foreach (SavingsAccount item in SavingsAccountList)
                {
                    if (item.AccountNo == searchAccountNo)
                    {
                        searchSavingsAccount = item;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchSavingsAccount;
        }

        //searching accounts by customerName
        public List<SavingsAccount> GetSavingsAccountsByCustomerNameDAL(string searchcustomerName)
        {
            List<SavingsAccount> SavingsAccountsbyCustomerName = new List<SavingsAccount>();
            try
            {
                foreach (SavingsAccount item in SavingsAccountList)
                {
                    if (item.CustomerName == searchcustomerName)
                    {
                        SavingsAccountsbyCustomerName.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return SavingsAccountsbyCustomerName;
        }


        //searching accounts by customerID
        public List<SavingsAccount> GetSavingsAccountsByCustomerIDDAL(string searchcustomerID)
        {
            List<SavingsAccount> SavingsAccountsByCustID = new List<SavingsAccount>();
            try
            {
                foreach (SavingsAccount item in SavingsAccountList)
                {
                    if (item.CustomerID == searchcustomerID)
                    {
                        SavingsAccountsByCustID.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return SavingsAccountsByCustID;
        }
        //Get Balance
        public double GetBalance(string accountNumber)
        {
            double balance = 0;
            foreach(SavingsAccount item in SavingsAccountList)
            {
                if(item.AccountNo == accountNumber)
                {
                    balance = item.Balance;
                }
            }
            return balance;
        }
        //Update Balance
        public double UpdateBalance(string accountNumber, double balance)
        {
            
            foreach (SavingsAccount item in SavingsAccountList)
            {
                if (item.AccountNo == accountNumber)
                {
                    item.Balance = balance;
                }
            }
            return balance;
        }

        //Updating or modifying account details
        public bool UpdateSavingsAccountDAL(SavingsAccount updateAccount)
        {
            bool SavingsAccountUpdated = false;
            try
            {
                for (int i = 0; i < SavingsAccountList.Count; i++)
                {
                    if (SavingsAccountList[i].AccountNo == updateAccount.AccountNo)
                    {
                        SavingsAccountList[i].CustomerName = updateAccount.CustomerName;
                        SavingsAccountList[i].Phone = updateAccount.Phone;
                        SavingsAccountList[i].EmailID = updateAccount.EmailID;
                        SavingsAccountList[i].Address = updateAccount.Address;
                        SavingsAccountList[i].AccountType = updateAccount.AccountType;
                        SavingsAccountList[i].MinimumBalance = updateAccount.MinimumBalance;
                        SavingsAccountList[i].InterestRate = updateAccount.InterestRate;
                        SavingsAccountList[i].Branch = updateAccount.Branch;
                        SavingsAccountUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return SavingsAccountUpdated;

        }

        public bool DeleteSavingsAccountDAL(string deleteAccountNo)
        {
            bool SavingsAccountDeleted = false;
            try
            {
                SavingsAccount deleteAccount = null;
                foreach (SavingsAccount item in SavingsAccountList)
                {
                    if (item.AccountNo == deleteAccountNo)
                    {
                        deleteAccount = item;
                    }

                    /*
                     item.Status = "Closed";
                     

                     */


                }

                if (deleteAccountNo != null)
                {
                    SavingsAccountList.Remove(deleteAccount);
                    SavingsAccountDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return SavingsAccountDeleted;

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    public class CurrentAccountBL
    {
        private static bool ValidateAccount(CurrentAccount account)
        {
            StringBuilder sb = new StringBuilder();
            bool validAccount = true;
            if (account.Balance < account.MinimumBalance)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Account balance can't be less than minimum balance");

            }
            if (account.MinimumBalance < 0)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Minimum balance can't be zero");

            }
            if (account.StartDate == DateTime.MinValue) 
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "StartDate can't be null");

            }
            if ((account.AccountType != "Savings")&&(account.AccountType != "Current")&&(account.AccountType != "Fixed"))
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "AccountType can be Savings or Current or Fixed");

            }

            if (validAccount == false)
                throw new PecuniaException(sb.ToString());
            return validAccount;
        }

        public static bool CreateAccountBL(CurrentAccount newAccount)
        {
            bool accountCreated = false;
            try
            {
                if (ValidateAccount(newAccount))
                {
                    CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                    accountCreated = accountDAL.CreateAccountDAL(newAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return accountCreated;
        }

        public static List<CurrentAccount> GetAllAccountsBL()
        {
            List<CurrentAccount> accountList = null;
            try
            {
                CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                accountList = accountDAL.GetAllAccountsDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountList;
        }

        public static CurrentAccount SearchAccountBL(string searchAccountNo)
        {
            CurrentAccount searchAccount = null;
            try
            {
                CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                searchAccount = accountDAL.SearchAccountDAL(searchAccountNo);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchAccount;

        }

        public static List<CurrentAccount> GetAccountsByCustomerIDBL(string searchcustomerID)
        {
            List<CurrentAccount> accountsbyCustID = null;
            try
            {
                CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                accountsbyCustID = accountDAL.GetAccountsByCustomerIDDAL(searchcustomerID);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyCustID;

        }

        public static List<CurrentAccount> GetAccountsByCustomerNameBL(string searchcustomerName)
        {
            List<CurrentAccount> accountsbyCustomerName = null;
            try
            {
                CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                accountsbyCustomerName = accountDAL.GetAccountsByCustomerNameDAL(searchcustomerName);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyCustomerName;

        }
        public static List<CurrentAccount> GetAccountsByBranchBL(string searchbranchname)
        {
            List<CurrentAccount> accountsbyBranch = null;
            try
            {
                CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                accountsbyBranch = accountDAL.GetAccountsByBranchDAL(searchbranchname);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyBranch;

        }


        public static bool UpdateAccountBL(CurrentAccount updateAccount)
        {
            bool accountUpdated = false;
            try
            {
                if (ValidateAccount(updateAccount))
                {
                    CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                    accountUpdated = accountDAL.UpdateAccountDAL(updateAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return accountUpdated;
        }

        public static bool DeleteAccountBL(string deleteAccountNo)
        {
            bool accountDeleted = false;
            try
            {
                Regex rgx = new Regex(@"^[1][0-9]{9}$");

                if (rgx.IsMatch(deleteAccountNo) == true)
                {
                    CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                    accountDeleted = accountDAL.DeleteAccountDAL(deleteAccountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return accountDeleted;
        }
       
    }
}

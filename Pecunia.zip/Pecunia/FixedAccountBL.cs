using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    public class FixedAccountBL
    {
        private static bool ValidateAccount(FixedAccount account)
        {
            StringBuilder sb = new StringBuilder();
            bool validAccount = true;
            if (account.Balance < account.MinimumBalance)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Account balance can't be less than minimum balance");

            }
            if (account.MinimumBalance < 0)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Minimum balance can't be zero");

            }
            if (account.StartDate == DateTime.MinValue) 
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "StartDate can't be null");

            }
			if (account.Tenure < 0) 
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Tenure can't be negative");

            }
            if ((account.AccountType != "Savings")&&(account.AccountType != "Current")&&(account.AccountType != "Fixed"))
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "AccountType can be Fixed or Current or Fixed");

            }

            if (validAccount == false)
                throw new PecuniaException(sb.ToString());
            return validAccount;
        }

        public static bool CreateFixedAccountBL(FixedAccount newAccount)
        {
            bool accountCreated = false;
            try
            {
                if (ValidateAccount(newAccount))
                {
                    FixedAccountDAL accountDAL = new FixedAccountDAL();
                    accountCreated = accountDAL.CreateFixedAccountDAL(newAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return accountCreated;
        }

        public static List<FixedAccount> GetAllFixedAccountsBL()
        {
            List<FixedAccount> accountList = null;
            try
            {
                FixedAccountDAL accountDAL = new FixedAccountDAL();
                accountList = accountDAL.GetAllFixedAccountsDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountList;
        }

        public static FixedAccount SearchFixedAccountByNoBL(string searchAccountNo)
        {
            CurrentAccount searchAccount = null;
            try
            {
                FixedAccountDAL accountDAL = new FixedAccountDAL();
                searchAccount = accountDAL.SearchFixedAccountByNoDAL(searchAccountNo);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchAccount;

        }

        public static List<FixedAccount> GetFixedAccountsByCustomerIDBL(string searchcustomerID)
        {
            List<FixedAccount> accountsbyCustID = null;
            try
            {
                FixedAccountDAL accountDAL = new SsvingsAccountDAL();
                accountsbyCustID = accountDAL.GetFixedAccountsByCustomerIDDAL(searchcustomerID);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyCustID;

        }

        public static List<FixedAccount> GetFixedAccountsByCustomerNameBL(string searchcustomerName)
        {
            List<FixedAccount> accountsbyCustomerName = null;
            try
            {
                FixedAccountDAL accountDAL = new FixedAccountDAL();
                accountsbyCustomerName = accountDAL.GetFixedAccountsByCustomerNameDAL(searchcustomerName);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyCustomerName;

        }


        // public static bool UpdateAccountBL(CurrentAccount updateAccount)
        // {
            // bool accountUpdated = false;
            // try
            // {
                // if (ValidateAccount(updateAccount))
                // {
                    // CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                    // accountUpdated = accountDAL.UpdateAccountDAL(updateAccount);
                // }
            // }
            // catch (PecuniaException)
            // {
                // throw;
            // }
            // catch (Exception ex)
            // {
                // throw ex;
            // }

            // return accountUpdated;
        // }

        public static bool DeleteFixedAccountBL(string deleteAccountNo)
        {
            bool accountDeleted = false;
            try
            {
                Regex rgx = new Regex(@"^[3]{1}[0-9]{9}$");

                if (rgx.IsMatch(deleteAccountNo) == true)
                {
                    FixedAccountDAL accountDAL = new FixedAccountDAL();
                    accountDeleted = accountDAL.DeleteFixedAccount(deleteAccountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return accountDeleted;
        }
       
    }
}

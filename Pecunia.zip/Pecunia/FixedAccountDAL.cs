using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Pecunia.Entities;
using Pecunia.Exceptions;

namespace Pecunia.DataAccessLayer
{
    public class FixedAccountDAL
    {
        public static List<FixedAccount> FixedAccountList = new List<FixedAccount>();

        public bool CreateFixedAccountDAL(FixedAccount newAccount)
        {
            bool FixedAccountCreated = false;
            try
            {
                FixedAccountList.Add(newAccount);
                accountCreated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return FixedAccountCreated;

        }

        public List<FixedAccount> GetAllFixedAccountsDAL()
        {
            return FixedAccountList;
        }

        public FixedAccount SearchFixedAccountDAL(string searchAccountNo)
        {
            FixedAccount searchAccount = null;
            try
            {
                foreach (FixedAccount item in FixedAccountList)
                {
                    if (item.AccountNo == searchAccountNo)
                    {
                        searchAccount = item;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchAccount;
        }

        //searching accounts by customerID
        public List<FixedAccount> GetFixedAccountsByCustomerIDDAL(string searchcustomerID)
        {
            List<FixedAccount> accountsbyCustID = new List<FixedAccount>();
            try
            {
                foreach (FixedAccount item in FixedAccountList)
                {
                    if (item.CustomerID == searchcustomerID)
                    {
                        accountsbyCustID.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountsbyCustID;
        }

        //searching accounts by customerName
        public List<FixedAccount> GetFixedAccountsByCustomerNameDAL(string searchcustomerName)
        {
            List<FixedAccount> accountsbyCustomerName = new List<FixedAccount>();
            try
            {
                foreach (FixedAccount item in FixedAccountList)
                {
                    if (item.CustomerName == searchcustomerName)
                    {
                        accountsbyCustomerName.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountsbyCustomerName;
        }

        //Updating or modifying account details
        

        public bool DeleteAccountDAL(string deleteAccountNo)
        {
            bool accountDeleted = false;
            try
            {
                FixedAccount deleteAccount = null;
                foreach (FixedAccount item in FixedAccountList)
                {
                    if (item.AccountNo == deleteAccountNo)
                    {
                        deleteAccount = item;
                    }
                }

                if (deleteAccountNo != null)
                {
                    FixedAccountList.Remove(deleteAccount);
                    accountDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountDeleted;

        }

    }
}

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    public class SavingsAccountBL
    {
        private static bool ValidateAccount(SavingsAccount account)
        {
            StringBuilder sb = new StringBuilder();
            bool validAccount = true;
            if (account.Balance < account.MinimumBalance)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Account balance can't be less than minimum balance");

            }
            if (account.MinimumBalance < 0)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Minimum balance can't be zero");

            }
            if (account.StartDate == DateTime.MinValue) 
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "StartDate can't be null");

            }
            if ((account.AccountType != "Savings")&&(account.AccountType != "Current")&&(account.AccountType != "Fixed"))
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "AccountType can be Savings or Current or Fixed");

            }

            if (validAccount == false)
                throw new PecuniaException(sb.ToString());
            return validAccount;
        }

        public static bool CreateSavingsAccountBL(SavingsAccount newAccount)
        {
            bool accountCreated = false;
            try
            {
                if (ValidateAccount(newAccount))
                {
                    SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                    accountCreated = accountDAL.CreateSavingsAccountDAL(newAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return accountCreated;
        }

        public static List<SavingsAccount> GetAllSavingsAccountsBL()
        {
            List<SavingsAccount> accountList = null;
            try
            {
                SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                accountList = accountDAL.GetAllSavingsAccountsDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountList;
        }

        public static SavingsAccount SearchSavingsAccountByNoBL(string searchAccountNo)
        {
            CurrentAccount searchAccount = null;
            try
            {
                SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                searchAccount = accountDAL.SearchSavingsAccountByNoDAL(searchAccountNo);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchAccount;

        }

        public static List<SAvingsAccount> GetSavingsAccountsByCustomerIDBL(string searchcustomerID)
        {
            List<SavingsAccount> accountsbyCustID = null;
            try
            {
                SavingsAccountDAL accountDAL = new SsvingsAccountDAL();
                accountsbyCustID = accountDAL.GetSavingsAccountsByCustomerIDDAL(searchcustomerID);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyCustID;

        }

        public static List<SavingsAccount> GetSavingsAccountsByCustomerNameBL(string searchcustomerName)
        {
            List<SavingsAccount> accountsbyCustomerName = null;
            try
            {
                SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                accountsbyCustomerName = accountDAL.GetSavingsAccountsByCustomerNameDAL(searchcustomerName);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return accountsbyCustomerName;

        }


        // public static bool UpdateAccountBL(CurrentAccount updateAccount)
        // {
            // bool accountUpdated = false;
            // try
            // {
                // if (ValidateAccount(updateAccount))
                // {
                    // CurrentAccountDAL accountDAL = new CurrentAccountDAL();
                    // accountUpdated = accountDAL.UpdateAccountDAL(updateAccount);
                // }
            // }
            // catch (PecuniaException)
            // {
                // throw;
            // }
            // catch (Exception ex)
            // {
                // throw ex;
            // }

            // return accountUpdated;
        // }

        public static bool DeleteSavingsAccountBL(string deleteAccountNo)
        {
            bool accountDeleted = false;
            try
            {
                Regex rgx = new Regex(@"^[1][0-9]{9}$");

                if (rgx.IsMatch(deleteAccountNo) == true)
                {
                    SavingsAccountDAL accountDAL = new SavingsAccountDAL();
                    accountDeleted = accountDAL.DeleteSavingsAccount(deleteAccountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return accountDeleted;
        }
       
    }
}

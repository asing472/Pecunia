using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Pecunia.Entities;
using Pecunia.Exceptions;

namespace Pecunia.DataAccessLayer
{
    public class SavingsAccountDAL
    {
        public static List<SavingsAccount> savingsAccountList = new List<SavingsAccount>();

        public bool CreateSavingsAccountDAL(SavingsAccount newAccount)
        {
            bool savingsAccountCreated = false;
            try
            {
                savingsAccountList.Add(newAccount);
                accountCreated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return savingsAccountCreated;

        }

        public List<SavingsAccount> GetAllSavingsAccountsDAL()
        {
            return savingsAccountList;
        }

        public SavingsAccount SearchSavingsAccountByNoDAL(string searchAccountNo)
        {
            SavingsAccount searchAccount = null;
            try
            {
                foreach (SavingsAccount item in savingsAccountList)
                {
                    if (item.AccountNo == searchAccountNo)
                    {
                        searchAccount = item;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchAccount;
        }

        //searching accounts by customerID
        public List<SavingsAccount> GetSavingsAccountsByCustomerIDDAL(string searchcustomerID)
        {
            List<SavingsAccount> accountsbyCustID = new List<SavingsAccount>();
            try
            {
                foreach (SavingsAccount item in savingsAccountList)
                {
                    if (item.CustomerID == searchcustomerID)
                    {
                        accountsbyCustID.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountsbyCustID;
        }

        //searching accounts by customerName
        public List<SavingsAccount> GetSavingsAccountsByCustomerNameDAL(string searchcustomerName)
        {
            List<SavingsAccount> accountsbyCustomerName = new List<SavingsAccount>();
            try
            {
                foreach (SavingsAccount item in savingsAccountList)
                {
                    if (item.CustomerName == searchcustomerName)
                    {
                        accountsbyCustomerName.Add(item);
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountsbyCustomerName;
        }

        //Updating or modifying account details
		
        

        public bool DeleteSavingsAccountDAL(string deleteAccountNo)
        {
            bool accountDeleted = false;
            try
            {
                SavingsAccount deleteAccount = null;
                foreach (SavingsAccount item in savingsAccountList)
                {
                    if (item.AccountNo == deleteAccountNo)
                    {
                        deleteAccount = item;
                    }
                }

                if (deleteAccountNo != null)
                {
                    savingsAccountList.Remove(deleteAccount);
                    accountDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return accountDeleted;

        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Pecunia.Entities;
using Pecunia.Exceptions;
using Pecunia.DataAccessLayer;
using System.Text.RegularExpressions;

namespace Pecunia.BusinessLayer
{
    public class AccountBL
    {
        private static bool ValidateAccount(Account account)
        {
            StringBuilder sb = new StringBuilder();
            bool validAccount = true;
            if (account.Balance < account.MinimumBalance)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Account balance can't be less than minimum balance");

            }
            if (account.MinimumBalance < 0)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "Minimum balance can't be zero");

            }
            if (account.StartDate == DateTime.MinValue)
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "StartDate can't be null");

            }
            if ((account.AccountType != "Savings") && (account.AccountType != "") && (account.AccountType != "Fixed"))
            {
                validAccount = false;
                sb.Append(Environment.NewLine + "AccountType can be Savings or  or Fixed");

            }

            if (validAccount == false)
                throw new PecuniaException(sb.ToString());
            return validAccount;
        }

        public static bool CreateAccountBL(Account newAccount)
        {
            bool AccountCreated = false;
            try
            {
                if (ValidateAccount(newAccount))
                {
                    AccountDAL accountDAL = new AccountDAL();
                    AccountCreated = accountDAL.CreateAccountDAL(newAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return AccountCreated;
        }

        public static List<Account> GetAllAccountsBL()
        {
            List<Account> AccountList = null;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                AccountList = accountDAL.GetAllAccountsDAL();
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return AccountList;
        }

        public static Account SearchAccountBL(string searchAccountNo)
        {
            Account searchAccount = null;
            try
            {
                AccountDAL accountDAL = new AccountDAL();
                searchAccount = accountDAL.SearchAccountDAL(searchAccountNo);
            }
            catch (PecuniaException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchAccount;

        }

        public static bool UpdateAccountBL(Account updateAccount)
        {
            bool AccountUpdated = false;
            try
            {
                if (ValidateAccount(updateAccount))
                {
                    AccountDAL accountDAL = new AccountDAL();
                    AccountUpdated = accountDAL.UpdateAccountDAL(updateAccount);
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return AccountUpdated;
        }

        public static bool DeleteAccountBL(string deleteAccountNo)
        {
            bool AccountDeleted = false;
            try
            {
                Regex rgx = new Regex(@"^[1]{1}[0-9]{9}$");

                if (rgx.IsMatch(deleteAccountNo) == true)
                {
                    AccountDAL accountDAL = new AccountDAL();
                    AccountDeleted = accountDAL.DeleteAccountDAL(deleteAccountNo);
                }
                else
                {
                    throw new PecuniaException("Invalid account no");
                }
            }
            catch (PecuniaException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return AccountDeleted;
        }

    }
}

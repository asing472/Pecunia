﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.Common;
using Pecunia.Entities;
using Pecunia.Exceptions;


namespace Pecunia.DataAccessLayer
{
    public class AccountDAL
    {
        public static List<Account> AccountList = new List<Account>();

        public bool CreateAccountDAL(Account newAccount)
        {
            bool AccountCreated = false;
            try
            {
                AccountList.Add(newAccount);
                AccountCreated = true;
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountCreated;

        }

        //List of all  accounts
        public List<Account> GetAllAccountsDAL()
        {
            return AccountList;
        }

        //searching  accounts by accountno
        public Account SearchAccountDAL(string searchAccountNo)
        {
            Account searchAccount = null;
            try
            {
                searchAccount = AccountList.Find(x => x.AccountNo == searchAccountNo);
                
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return searchAccount;
        }

        //searching  accounts by customerID
        public List<Account> GetAccountsByCustomerIDDAL(string searchCustomerID)
        {
            List<Account> AccountsByCustID = new List<Account>();
            try
            {
               
                AccountsByCustID.AddRange(AccountList.FindAll(x => x.aCustomerID == searchCustomerID));       
                
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByCustID;
        }

        //searching accounts by customerName
        public List<Account> GetAccountsByCustomerNameDAL(string searchCustomerName)
        {
            List<Account> AccountsByCustomerName = new List<Account>();
            try
            {
                AccountsByCustomerName.AddRange(AccountList.FindAll(x => x.aCustomerName == searchCustomerName));
                
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByCustomerName;
        }

        //searching accounts by type
        public List<Account> GetAccountsByTypeDAL(string searchAccountType)
        {
            List<Account> AccountsByType = new List<Account>();
            try
            {
                AccountsByType.AddRange(AccountList.FindAll(x => x.AccountType == searchAccountType));

            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByType;
        }

        //searching accounts by branch
        public List<Account> GetAccountsByBranchDAL(string searchBranch)
        {
            List<Account> AccountsByBranch = new List<Account>();
            try
            {
                AccountsByBranch.AddRange(AccountList.FindAll(x => x.Branch == searchBranch));

            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountsByBranch;
        }

        //Get Balance
        public double GetBalance(string accountNumber)
        {
            double balance = 0;

            //AccountList.Find(x => x.AccountNo == accountNumber);

            foreach (Account item in AccountList)
            {
                if (item.AccountNo == accountNumber)
                {
                    balance = item.Balance;
                }
            }
            return balance;
        }
        //Update Balance
        public double UpdateBalance(string accountNumber, double balance)
        {
            //AccountList.Find(x => x.AccountNo == accountNumber);

            foreach (Account item in AccountList)
            {
                if (item.AccountNo == accountNumber)
                {
                    item.Balance = balance;
                }
            }
            return balance;
        }

        //Updating or modifying account details
        public bool UpdateAccountDAL(Account updateAccount)
        {
            bool AccountUpdated = false;
            try
            {
                for (int i = 0; i < AccountList.Count; i++)
                {
                    if (AccountList[i].Accountno == updateAccount.Accountno)
                    {
                        AccountList[i].CustomerName = updateAccount.CustomerName;
                        AccountList[i].Phone = updateAccount.Phone;
                        AccountList[i].EmailID = updateAccount.EmailID;
                        AccountList[i].Address = updateAccount.Address;
                        AccountList[i].AccountType = updateAccount.AccountType;
                        AccountList[i].MinimumBalance = updateAccount.MinimumBalance;
                        AccountList[i].InterestRate = updateAccount.InterestRate;
                        AccountList[i].Branch = updateAccount.Branch;
                        AccountUpdated = true;
                    }
                }
            }
            catch (SystemException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountUpdated;

        }

        public bool DeleteAccountDAL(string deleteAccountNo)
        {
            bool AccountDeleted = false;
            try
            {
                //AccountList.Find(x => x.AccountNo == deleteAccountNo);
                Account deleteAccount = null;
                foreach (Account item in AccountList)
                {
                    if (item.Accountno == deleteAccountNo)
                    {
                        deleteAccount = item;
                    }

                    /*
                     item.Status = "Closed";
                     

                     */


                }

                if (deleteAccountNo != null)
                {
                    AccountList.Remove(deleteAccount);
                    AccountDeleted = true;
                }
            }
            catch (DbException ex)
            {
                throw new PecuniaException(ex.Message);
            }
            return AccountDeleted;

        }

    }
}
